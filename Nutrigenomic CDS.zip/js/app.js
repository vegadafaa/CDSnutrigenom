/**
 * NutriGen-CDS: Clinical Decision Support Orchestrator
 * Main application controller managing reactive state, UI tab routing,
 * ingestion events, and real-time clinical evaluations.
 */

const App = {
  currentPatient: null,
  currentEvaluation: null,
  currentFhirBundle: null,

  init: function() {
    this.populatePatientSelector();
    this.bindEvents();
    
    // Load default patient (Arthur Pendelton)
    if (typeof SAMPLE_PATIENTS !== 'undefined' && SAMPLE_PATIENTS.length > 0) {
      this.loadPatient(SAMPLE_PATIENTS[0].id);
    }

    this.renderKnowledgeBaseTable();
  },

  populatePatientSelector: function() {
    const selector = document.getElementById("patientSelector");
    if (!selector || typeof SAMPLE_PATIENTS === 'undefined') return;

    selector.innerHTML = SAMPLE_PATIENTS.map(p => `
      <option value="${p.id}">${p.name} (${p.id}) - ${p.primaryGoals[0] || 'Clinical Case'}</option>
    `).join('');
  },

  bindEvents: function() {
    // Patient dropdown change
    const selector = document.getElementById("patientSelector");
    if (selector) {
      selector.addEventListener("change", (e) => {
        this.loadPatient(e.target.value);
      });
    }

    // Tab buttons
    const tabBtns = document.querySelectorAll(".tab-btn");
    tabBtns.forEach(btn => {
      btn.addEventListener("click", () => {
        const targetId = btn.getAttribute("data-tab");
        this.switchTab(targetId);
      });
    });

    // File Dropzone / Upload
    const fileInput = document.getElementById("genomicFileInput");
    const dropzone = document.getElementById("dropzoneArea");

    if (dropzone && fileInput) {
      dropzone.addEventListener("click", () => fileInput.click());
      
      dropzone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropzone.classList.add("dragover");
      });

      dropzone.addEventListener("dragleave", () => {
        dropzone.classList.remove("dragover");
      });

      dropzone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropzone.classList.remove("dragover");
        if (e.dataTransfer.files.length > 0) {
          this.handleFileUpload(e.dataTransfer.files[0]);
        }
      });

      fileInput.addEventListener("change", (e) => {
        if (e.target.files.length > 0) {
          this.handleFileUpload(e.target.files[0]);
        }
      });
    }

    // Knowledge base search
    const kbSearch = document.getElementById("kbSearchInput");
    if (kbSearch) {
      kbSearch.addEventListener("input", (e) => {
        this.renderKnowledgeBaseTable(e.target.value);
      });
    }

    // Print button
    const printBtn = document.getElementById("btnPrintReport");
    if (printBtn) {
      printBtn.addEventListener("click", () => window.print());
    }
  },

  switchTab: function(tabId) {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-pane").forEach(p => p.classList.remove("active"));

    const activeBtn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
    const activePane = document.getElementById(tabId);

    if (activeBtn) activeBtn.classList.add("active");
    if (activePane) activePane.classList.add("active");

    // If switching to risk matrix, ensure radar chart redraws
    if (tabId === "tab-risk" && this.currentEvaluation) {
      SVGRadarChart.render("#radarChartContainer", this.currentEvaluation.domainAssessments);
    }
  },

  loadPatient: function(patientId) {
    const found = SAMPLE_PATIENTS.find(p => p.id === patientId);
    if (!found) return;

    // Deep clone to allow safe local modification
    this.currentPatient = JSON.parse(JSON.stringify(found));
    this.runEvaluation();
  },

  handleFileUpload: function(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target.result;
      const parsedGenotypes = GenomicParsers.autoParse(content, NUTRIGENOMICS_KB);

      const parsedCount = Object.keys(parsedGenotypes).length;
      if (parsedCount === 0) {
        alert("No recognized nutrigenomic variants found in this file. Please verify format (VCF, 23andMe, or JSON).");
        return;
      }

      // Merge into current patient
      this.currentPatient.genotypes = {
        ...(this.currentPatient.genotypes || {}),
        ...parsedGenotypes
      };

      const statusEl = document.getElementById("uploadStatusMessage");
      if (statusEl) {
        statusEl.innerHTML = `<span style="color: #059669; font-weight: 600;">Successfully parsed ${parsedCount} nutrigenomic variants from ${file.name}!</span>`;
      }

      this.runEvaluation();
    };
    reader.readAsText(file);
  },

  runEvaluation: function() {
    if (!this.currentPatient) return;

    // 1. Run CDS Rule Engine
    this.currentEvaluation = CDSRuleEngine.evaluatePatient(this.currentPatient, NUTRIGENOMICS_KB);

    // 2. Generate HL7 FHIR Bundle
    this.currentFhirBundle = FHIRExporter.exportToFHIRBundle(this.currentPatient, this.currentEvaluation);

    // 3. Update UI views
    this.updatePatientVitalsBar();
    this.renderIntakeView();
    this.renderRiskMatrixView();
    this.renderNutritionRxView();
    this.renderSafetyView();
    this.renderReportsView();
    this.renderFhirView();
    this.updateNotificationBadges();
  },

  updatePatientVitalsBar: function() {
    const p = this.currentPatient;
    const bar = document.getElementById("patientVitalsBar");
    if (!bar || !p) return;

    bar.innerHTML = `
      <div class="pt-demographics">
        <div class="pt-avatar">${p.name.charAt(0)}</div>
        <div class="pt-name-id">
          <h3>${p.name}</h3>
          <span>ID: ${p.id} | Age: ${p.age} y.o. | ${p.gender.toUpperCase()}</span>
        </div>
      </div>
      <div class="pt-vitals-strip">
        <div class="vital-metric">
          <span class="metric-name">BMI</span>
          <span class="metric-value">${p.bmi} kg/m²</span>
        </div>
        <div class="vital-metric">
          <span class="metric-name">Blood Pressure</span>
          <span class="metric-value">${p.bloodPressure || 'N/A'}</span>
        </div>
        <div class="vital-metric">
          <span class="metric-name">Diet Baseline</span>
          <span class="metric-value">${p.dietPattern || 'Omnivore'}</span>
        </div>
        <div class="vital-metric">
          <span class="metric-name">Overall Status</span>
          <span class="metric-value"><span class="badge ${this.currentEvaluation.overallRiskStatus.class.replace('risk-', 'badge-')}">${this.currentEvaluation.overallRiskStatus.level}</span></span>
        </div>
      </div>
    `;
  },

  renderIntakeView: function() {
    const p = this.currentPatient;
    const tableBody = document.getElementById("intakeGenotypesTableBody");
    if (!tableBody) return;

    const genotypes = p.genotypes || {};
    const rows = Object.entries(genotypes).map(([rsid, call]) => {
      const kbEntry = NUTRIGENOMICS_KB[rsid];
      const gtData = kbEntry && kbEntry.genotypes ? kbEntry.genotypes[call.genotype] : null;

      return `
        <tr>
          <td><strong>${call.gene}</strong></td>
          <td>${call.variantName || rsid}</td>
          <td><code>${rsid}</code></td>
          <td><code class="genotype-tag">${call.genotype}</code></td>
          <td>${gtData ? gtData.phenotype : 'Genotype identified'}</td>
          <td><span class="tier-pill ${kbEntry ? kbEntry.evidenceTier.toLowerCase().replace(' ', '-') : 'tier-c'}">${kbEntry ? kbEntry.evidenceTier : 'Tier B'}</span></td>
        </tr>
      `;
    }).join('');

    tableBody.innerHTML = rows || `<tr><td colspan="6" class="text-muted text-center">No genomic data loaded.</td></tr>`;

    // Labs table
    const labsBody = document.getElementById("intakeBiomarkersTableBody");
    if (labsBody && p.biomarkers) {
      labsBody.innerHTML = Object.entries(p.biomarkers).map(([key, lab]) => `
        <tr>
          <td><strong>${key}</strong></td>
          <td><strong>${lab.value}</strong> ${lab.unit}</td>
          <td>${lab.reference}</td>
          <td><span class="badge ${lab.status && lab.status.includes('elevated') ? 'badge-high' : (lab.status && lab.status.includes('deficient') ? 'badge-high' : 'badge-optimal')}">${lab.status}</span></td>
        </tr>
      `).join('');
    }
  },

  renderRiskMatrixView: function() {
    if (!this.currentEvaluation) return;
    const domains = this.currentEvaluation.domainAssessments;

    // Render SVG Radar
    SVGRadarChart.render("#radarChartContainer", domains);

    // Render Domain Cards
    const container = document.getElementById("domainCardsContainer");
    if (!container) return;

    container.innerHTML = Object.entries(domains).map(([key, d]) => `
      <div class="card" style="margin-bottom: 1rem;">
        <div class="card-header">
          <div class="card-title">
            <span>${d.name}</span>
          </div>
          <span class="badge ${d.badgeClass}">${d.category} (${d.percentageScore}%)</span>
        </div>
        <div class="table-responsive">
          <table class="clinical-table">
            <thead>
              <tr>
                <th>Gene</th>
                <th>Genotype</th>
                <th>Evidence</th>
                <th>Phenotypic Impact & Guidance</th>
              </tr>
            </thead>
            <tbody>
              ${d.snpResults.map(snp => `
                <tr>
                  <td><strong>${snp.gene}</strong><br/><small class="text-muted">${snp.rsid}</small></td>
                  <td><code class="genotype-tag">${snp.genotype}</code></td>
                  <td><span class="tier-pill ${snp.evidenceTier.toLowerCase().replace(' ', '-')}">${snp.evidenceTier}</span></td>
                  <td>
                    <div>${snp.phenotype}</div>
                    ${snp.dietaryGuidance ? `<small style="color: #0369a1; display: block; margin-top: 0.25rem;"><strong>Dietary Action:</strong> ${snp.dietaryGuidance}</small>` : ''}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `).join('');
  },

  renderNutritionRxView: function() {
    if (!this.currentEvaluation) return;
    const macro = this.currentEvaluation.macronutrientRx || {};
    const formulary = this.currentEvaluation.supplementFormulary || [];
    const food = this.currentEvaluation.foodGuidance || { prioritize: [], restrictOrAvoid: [] };

    // Macronutrient cards
    const macroContainer = document.getElementById("macroTargetContainer");
    if (macroContainer) {
      macroContainer.innerHTML = `
        <div class="macro-card">
          <span class="macro-label">Prescribed Energy</span>
          <span class="macro-val">${macro.dailyCalories} kcal/d</span>
          <span class="macro-sub">Estimated BMR: ~${macro.bmr} kcal/d</span>
        </div>
        <div class="macro-card">
          <span class="macro-label">Carbohydrate</span>
          <span class="macro-val">${macro.distribution ? macro.distribution.carbohydrate.grams : 0}g (${macro.distribution ? macro.distribution.carbohydrate.percentage : 0}%)</span>
          <span class="macro-sub">${macro.distribution ? macro.distribution.carbohydrate.focus : ''}</span>
        </div>
        <div class="macro-card">
          <span class="macro-label">Protein Target</span>
          <span class="macro-val">${macro.distribution ? macro.distribution.protein.grams : 0}g (${macro.distribution ? macro.distribution.protein.percentage : 0}%)</span>
          <span class="macro-sub">${macro.distribution ? macro.distribution.protein.focus : ''}</span>
        </div>
        <div class="macro-card">
          <span class="macro-label">Fat & Saturated Ceiling</span>
          <span class="macro-val">${macro.distribution ? macro.distribution.fat.grams : 0}g (${macro.distribution ? macro.distribution.fat.percentage : 0}%)</span>
          <span class="macro-sub">${macro.distribution ? macro.distribution.saturatedFatCeiling : ''}</span>
        </div>
      `;
    }

    // Formulary table
    const formularyBody = document.getElementById("supplementFormularyTableBody");
    if (formularyBody) {
      formularyBody.innerHTML = formulary.map(sup => `
        <tr>
          <td><strong>${sup.nutrient}</strong></td>
          <td>${sup.form}</td>
          <td><strong>${sup.dosage}</strong><br/><small class="text-muted">${sup.timing}</small></td>
          <td>${sup.rationale} <span class="tier-pill ${sup.evidenceTier.toLowerCase().replace(' ', '-')}">${sup.evidenceTier}</span></td>
          <td><small>${sup.monitoring}</small></td>
        </tr>
      `).join('');
    }

    // Food list
    const foodPrioritize = document.getElementById("foodPrioritizeList");
    const foodAvoid = document.getElementById("foodAvoidList");

    if (foodPrioritize) {
      foodPrioritize.innerHTML = food.prioritize.map(f => `
        <li>
          <strong>${f.food}</strong>
          <div class="food-sub">${f.reason}</div>
        </li>
      `).join('');
    }

    if (foodAvoid) {
      foodAvoid.innerHTML = food.restrictOrAvoid.map(f => `
        <li>
          <strong>${f.food}</strong>
          <div class="food-sub">${f.reason}</div>
        </li>
      `).join('');
    }
  },

  renderSafetyView: function() {
    if (!this.currentEvaluation) return;
    const safety = this.currentEvaluation.safetyAlerts || [];
    const concordance = this.currentEvaluation.concordanceAlerts || [];
    const epistasis = this.currentEvaluation.epistasisAlerts || [];

    const container = document.getElementById("safetyAlertsContainer");
    if (!container) return;

    let html = '';

    // Safety & Contraindications
    if (safety.length > 0) {
      html += `
        <div class="card">
          <div class="card-title" style="color: #b91c1c; margin-bottom: 1rem;">
            &#9888; Drug-Gene-Nutrient Safety Warnings & Depletions (${safety.length})
          </div>
          ${safety.map(s => `
            <div class="alert-item alert-${s.severity}">
              <strong>${s.title}</strong>
              <p>${s.alertText || s.mechanism}</p>
              <p class="action-highlight"><strong>Directive:</strong> ${s.clinicalDirective}</p>
              ${s.geneSynergy ? `<small style="display:block; margin-top:0.3rem; color: #7c2d12;"><strong>Gene Synergy:</strong> ${s.geneSynergy}</small>` : ''}
            </div>
          `).join('')}
        </div>
      `;
    }

    // Concordance
    if (concordance.length > 0) {
      html += `
        <div class="card">
          <div class="card-title" style="color: #0369a1; margin-bottom: 1rem;">
            &#9745; Lab Biomarker vs. Genotype Concordance Findings (${concordance.length})
          </div>
          ${concordance.map(c => `
            <div class="concordance-item priority-${c.priority.toLowerCase()}">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <strong>${c.title}</strong>
                <span class="badge badge-${c.priority.toLowerCase()}">${c.priority}</span>
              </div>
              <p><em>${c.biomarker} | ${c.genotype}</em></p>
              <p>${c.clinicalSignificance}</p>
              <p class="action-highlight"><strong>Clinical Action:</strong> ${c.actionDirective}</p>
            </div>
          `).join('')}
        </div>
      `;
    }

    // Epistasis
    if (epistasis.length > 0) {
      html += `
        <div class="card">
          <div class="card-title" style="color: #7c3aed; margin-bottom: 1rem;">
            &#9776; Multi-Gene Epistasis & Synergistic Vulnerabilities (${epistasis.length})
          </div>
          ${epistasis.map(e => `
            <div class="epistasis-item">
              <strong>${e.title} [${e.evidenceTier}]</strong>
              <p>${e.mechanism}</p>
              <p class="action-highlight"><strong>Prescription Directive:</strong> ${e.clinicalDirective}</p>
            </div>
          `).join('')}
        </div>
      `;
    }

    if (!html) {
      html = `<div class="card"><p class="text-muted">No safety contraindications or active epistasis flags triggered for this patient profile.</p></div>`;
    }

    container.innerHTML = html;
  },

  renderReportsView: function() {
    if (!this.currentPatient || !this.currentEvaluation) return;

    const soapContainer = document.getElementById("soapReportContainer");
    const patientPlanContainer = document.getElementById("patientCarePlanContainer");

    if (soapContainer) {
      soapContainer.innerHTML = ReportView.renderSoapReport(this.currentPatient, this.currentEvaluation);
    }

    if (patientPlanContainer) {
      patientPlanContainer.innerHTML = ReportView.renderPatientPlan(this.currentPatient, this.currentEvaluation);
    }
  },

  toggleReportView: function(viewType) {
    const soapContainer = document.getElementById("soapReportContainer");
    const patientPlanContainer = document.getElementById("patientCarePlanContainer");
    const btnPatient = document.getElementById("btnViewPatientPlan");
    const btnSoap = document.getElementById("btnViewSoap");

    if (viewType === 'soap') {
      if (soapContainer) soapContainer.style.display = 'block';
      if (patientPlanContainer) patientPlanContainer.style.display = 'none';
      if (btnSoap) { btnSoap.className = "btn btn-primary btn-sm"; }
      if (btnPatient) { btnPatient.className = "btn btn-secondary btn-sm"; }
    } else {
      if (soapContainer) soapContainer.style.display = 'none';
      if (patientPlanContainer) patientPlanContainer.style.display = 'block';
      if (btnPatient) { btnPatient.className = "btn btn-primary btn-sm"; }
      if (btnSoap) { btnSoap.className = "btn btn-secondary btn-sm"; }
    }
  },

  renderFhirView: function() {
    if (!this.currentFhirBundle) return;
    const container = document.getElementById("fhirViewerContainer");
    if (container) {
      container.innerHTML = ReportView.renderFhirViewer(this.currentFhirBundle);
    }
  },

  updateNotificationBadges: function() {
    if (!this.currentEvaluation) return;
    const safetyCount = (this.currentEvaluation.safetyAlerts || []).length;
    const epistasisCount = (this.currentEvaluation.epistasisAlerts || []).length;
    const totalAlerts = safetyCount + epistasisCount;

    const badge = document.getElementById("safetyTabBadge");
    if (badge) {
      badge.innerText = totalAlerts;
      badge.style.display = totalAlerts > 0 ? "inline-block" : "none";
      if (safetyCount > 0) {
        badge.className = "tab-count badge-high";
      } else {
        badge.className = "tab-count";
      }
    }
  },

  renderKnowledgeBaseTable: function(searchTerm = "") {
    const tableBody = document.getElementById("knowledgeBaseTableBody");
    if (!tableBody || typeof NUTRIGENOMICS_KB === 'undefined') return;

    const term = searchTerm.toLowerCase();
    const rows = Object.values(NUTRIGENOMICS_KB).filter(entry => {
      if (!term) return true;
      return (
        entry.gene.toLowerCase().includes(term) ||
        entry.rsid.toLowerCase().includes(term) ||
        entry.variantName.toLowerCase().includes(term) ||
        entry.domain.toLowerCase().includes(term) ||
        entry.clinicalSummary.toLowerCase().includes(term)
      );
    }).map(entry => `
      <tr>
        <td><strong>${entry.gene}</strong></td>
        <td><code>${entry.rsid}</code></td>
        <td>${entry.variantName}</td>
        <td>Chr ${entry.chromosome}:${entry.position}</td>
        <td>${entry.domainLabel}</td>
        <td><span class="tier-pill ${entry.evidenceTier.toLowerCase().replace(' ', '-')}">${entry.evidenceTier}</span></td>
        <td>
          <small>${entry.clinicalSummary}</small>
          <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.2rem;">
            Refs: ${entry.references.join(', ')}
          </div>
        </td>
      </tr>
    `).join('');

    tableBody.innerHTML = rows;
  }
};

// Start application
document.addEventListener("DOMContentLoaded", () => App.init());
